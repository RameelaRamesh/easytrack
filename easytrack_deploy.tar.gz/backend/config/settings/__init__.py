# Django settings package
